import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

public class AnimationModelImplTest {

  Size redSquareSize = new Size(100, 100);
  Position2D redSquarePosition = new Position2D(50,50);
  ShapeColor redSquareColor = new ShapeColor(255,0,0);
  Shape redSquare = new Square("red square", redSquarePosition,redSquareSize,redSquareColor);


  Size blueSquareSize = new Size(65, 30);
  Position2D blueSquarePosition = new Position2D(20,90);
  ShapeColor blueSquareColor = new ShapeColor(0,0,255);
  Shape blueSquare = new Square("blue square", blueSquarePosition,blueSquareSize,blueSquareColor);

  Size greenSquareSize = new Size(120, 72);
  Position2D greenSquarePosition = new Position2D(40,15);
  ShapeColor greenSquareColor = new ShapeColor(0,255,0);
  Shape greenSquare = new Square("green square", greenSquarePosition,greenSquareSize,greenSquareColor);


  AnimationModelImpl animationModel = new AnimationModelImpl();



  @Test
  public void testAddShape() {
  animationModel.addShape(redSquare);

  assertEquals("shape red square Square\n",animationModel.outputDescriptions());
}

  @Test
  public void testChangePosition() {
    animationModel.addShape(redSquare);
    Position2D newPosition = new Position2D(50,75);
    assertEquals(redSquarePosition, redSquare.getPosition());
    animationModel.changePosition("red square",newPosition,1,5);

    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   5 50.000000 75.000000 100 100 255 0 0\n",animationModel.outputDescriptions());
    assertEquals(newPosition, redSquare.getPosition());
  }

  @Test
  public void testChangePositionMultipleChanges() {
    animationModel.addShape(redSquare);
    Position2D Position2 = new Position2D(50,75);
    Position2D Position3 = new Position2D(100,100);
    assertEquals(redSquarePosition, redSquare.getPosition());

    animationModel.changePosition("red square",Position2,1,5);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   5 50.000000 75.000000 100 100 255 0 "
        + "0\n", animationModel.outputDescriptions());
    assertEquals(Position2, redSquare.getPosition());

    animationModel.changePosition("red square", Position3, 5, 10);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   5 50.000000 75.000000 100 100 255 0 0\n"
        + "motion 5 50.000000 75.000000 100 100 255 0 0   10 100.000000 100.000000 100 100 255 0 "
        + "0\n", animationModel.outputDescriptions());
    assertEquals(Position3, redSquare.getPosition());
  }

  @Test
  public void testChangeSize() {
    animationModel.addShape(redSquare);
    Size size2 = new Size(30, 30);
    assertEquals(redSquareSize, redSquare.getSize());

    animationModel.changeSize("red square", size2, 1, 10);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 30 30 255 0 "
        + "0\n", animationModel.outputDescriptions());
    assertEquals(size2, redSquare.getSize());
  }

  @Test
  public void testChangeSizeMultipleChanges() {
    animationModel.addShape(redSquare);
    Size size2 = new Size(30, 30);
    Size size3 = new Size(50, 50);
    Size size4 = new Size(75, 75);
    assertEquals(redSquareSize, redSquare.getSize());

    animationModel.changeSize("red square", size2, 1, 10);
    animationModel.changeSize("red square", size3, 11, 15);
    animationModel.changeSize("red square", size4, 16, 20);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 30 30 255 0 "
        + "0\n"
        + "motion 11 50.000000 50.000000 30 30 255 0 0   15 50.000000 50.000000 50 50 255 0 0\n"
        + "motion 16 50.000000 50.000000 50 50 255 0 0   20 50.000000 50.000000 75 75 255 0 0\n",
        animationModel.outputDescriptions());
    assertEquals(size4, redSquare.getSize());
  }

  @Test
  public void testChangeColor() {
    animationModel.addShape(redSquare);
    ShapeColor blue = new ShapeColor(0, 0, 255);
    assertEquals(redSquareColor, redSquare.getColor());

    animationModel.changeColor("red square", blue, 1, 10);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 100 100 0 0 "
        + "255\n", animationModel.outputDescriptions());
    assertEquals(blue, redSquare.getColor());
  }

  @Test
  public void testChangeColorMultipleChanges() {
    animationModel.addShape(redSquare);
    ShapeColor blue = new ShapeColor(0, 0, 255);
    ShapeColor green = new ShapeColor(0, 255, 0);
    assertEquals(redSquareColor, redSquare.getColor());

    animationModel.changeColor("red square", blue, 1, 10);
    animationModel.changeColor("red square", green, 11, 15);
    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 100 100 0 0 "
        + "255\n"
        + "motion 11 50.000000 50.000000 100 100 0 0 255   15 50.000000 50.000000 100 100 0 255 "
            + "0\n",
        animationModel.outputDescriptions());
    assertEquals(green, redSquare.getColor());
  }

  @Test
  public void testChangeColorAndPosition() {
    animationModel.addShape(redSquare);
    ShapeColor blue = new ShapeColor(0, 0, 255);
    Position2D newPosition = new Position2D(50,75);
    assertEquals(redSquareColor, redSquare.getColor());

    animationModel.changeColor("red square", blue, 1, 10);
    animationModel.changePosition("red square", newPosition, 11, 15);
    assertEquals("shape red square Square\n"
            + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 100 100 0 0 "
            + "255\n"
//            + "motion 10 50.000000 50.000000 100 100 0 0 255   11 50.000000 50.000000 100 100 0 0"
//            + " 255"
            + "motion 11 50.000000 50.000000 100 100 0 0 255   15 50.000000 75.000000 100 100 0 0 "
            + "255\n",
        animationModel.outputDescriptions());
    assertEquals(blue, redSquare.getColor());
    assertEquals(newPosition, redSquare.getPosition());
  }

  @Test
  public void testAllChangesInOneLog() {
    animationModel.addShape(redSquare);
    ShapeColor blue = new ShapeColor(0, 0, 255);
    Size size2 = new Size(30, 30);
    Position2D newPosition = new Position2D(50,75);

    assertEquals(redSquareColor, redSquare.getColor());
    assertEquals(redSquareSize, redSquare.getSize());
    assertEquals(redSquarePosition, redSquare.getPosition());

    animationModel.changeColor("red square", blue, 1, 10);
    animationModel.changeSize("red square", size2, 1, 10);
    animationModel.changePosition("red square",newPosition,1,10);


    assertEquals("shape red square Square\n"
            + "motion 1 50.000000 50.000000 100 100 255 0 0   5 50.000000 75.000000 30 30 0 0 255\n",animationModel.outputDescriptions());

    assertEquals(blue, redSquare.getColor());
    assertEquals(size2, redSquare.getSize());
    assertEquals(newPosition, redSquare.getPosition());
  }


  @Test
  public void testAddInOrder() {
    Size redSquareSize2 = new Size(107, 110);
    Position2D redSquarePosition2 = new Position2D(50,50);
    ShapeColor redSquareColor2 = new ShapeColor(255,0,0);
    Shape redSquare2 = new Square("red square 2", redSquarePosition2,redSquareSize2,redSquareColor2);

    Size redSquareSize3 = new Size(107, 110);
    Position2D redSquarePosition3 = new Position2D(50,50);
    ShapeColor redSquareColor3 = new ShapeColor(255,0,0);
    Shape redSquare3 = new Square("red square 3", redSquarePosition3,redSquareSize3,redSquareColor3);


    ShapeLog log1 = new ShapeLog(redSquare,1,redSquare2,10);
    ShapeLog log2 = new ShapeLog(redSquare2,10,redSquare3,15);
    ArrayList<ShapeLog> arraylog =  new ArrayList<ShapeLog>(Arrays.asList(log1));

    ArrayList<ShapeLog> expectedlog = new ArrayList<ShapeLog>(Arrays.asList(log1,log2));

    animationModel.addInOrder(arraylog,log2);

    assertEquals(expectedlog, arraylog);

  }

  @Test
  public void testAddInOrder2() {
    Size redSquareSize2 = new Size(107, 110);
    Position2D redSquarePosition2 = new Position2D(50,50);
    ShapeColor redSquareColor2 = new ShapeColor(255,0,0);
    Shape redSquare2 = new Square("red square 2", redSquarePosition2,redSquareSize2,redSquareColor2);

    Size redSquareSize3 = new Size(107, 110);
    Position2D redSquarePosition3 = new Position2D(50,50);
    ShapeColor redSquareColor3 = new ShapeColor(255,0,0);
    Shape redSquare3 = new Square("red square 3", redSquarePosition3,redSquareSize3,redSquareColor3);


    ShapeLog log1 = new ShapeLog(redSquare,1,redSquare2,10);
    ShapeLog log2 = new ShapeLog(redSquare2,10,redSquare3,15);
    ArrayList<ShapeLog> arraylog =  new ArrayList<ShapeLog>(Arrays.asList(log2));

    ArrayList<ShapeLog> expectedlog = new ArrayList<ShapeLog>(Arrays.asList(log1,log2));

    animationModel.addInOrder(arraylog,log1);

    assertEquals(expectedlog, arraylog);


  }

  @Test
  public void testAddInOrder3() {
    Size redSquareSize2 = new Size(107, 110);
    Position2D redSquarePosition2 = new Position2D(50,50);
    ShapeColor redSquareColor2 = new ShapeColor(255,0,0);
    Shape redSquare2 = new Square("red square 2", redSquarePosition2,redSquareSize2,redSquareColor2);

    Size redSquareSize3 = new Size(107, 110);
    Position2D redSquarePosition3 = new Position2D(50,50);
    ShapeColor redSquareColor3 = new ShapeColor(255,0,0);
    Shape redSquare3 = new Square("red square 3", redSquarePosition3,redSquareSize3,redSquareColor3);

    Size redSquareSize4 = new Size(107, 110);
    Position2D redSquarePosition4 = new Position2D(50,50);
    ShapeColor redSquareColor4 = new ShapeColor(255,0,0);
    Shape redSquare4 = new Square("red square 3", redSquarePosition4,redSquareSize4,redSquareColor4);


    ShapeLog log1 = new ShapeLog(redSquare,1,redSquare2,10);
    ShapeLog log2 = new ShapeLog(redSquare2,10,redSquare3,15);
    ShapeLog log3 = new ShapeLog(redSquare3,15,redSquare4,20);
    ArrayList<ShapeLog> arraylog =  new ArrayList<ShapeLog>(Arrays.asList(log2));

    ArrayList<ShapeLog> expectedlog = new ArrayList<ShapeLog>(Arrays.asList(log1,log2,log3));

    animationModel.addInOrder(arraylog,log1);
    animationModel.addInOrder(arraylog,log3);

    assertEquals(expectedlog, arraylog);


  }

  @Test
  public void testNewMotion(){
    animationModel.addShape(redSquare);

    Size redSquareSize2 = new Size(107, 110);
    Position2D redSquarePosition2 = new Position2D(50,50);
    ShapeColor redSquareColor2 = new ShapeColor(255,0,0);
    Shape redSquare2 = new Square("red square 2", redSquarePosition2,redSquareSize2,redSquareColor2);

    Size redSquareSize3 = new Size(107, 120);
    Position2D redSquarePosition3 = new Position2D(55,50);
    ShapeColor redSquareColor3 = new ShapeColor(255,0,0);
    Shape redSquare3 = new Square("red square 3", redSquarePosition3,redSquareSize3,redSquareColor3);

    Size redSquareSize4 = new Size(107, 110);
    Position2D redSquarePosition4 = new Position2D(50,50);
    ShapeColor redSquareColor4 = new ShapeColor(255,0,0);
    Shape redSquare4 = new Square("red square 4", redSquarePosition4,redSquareSize4,redSquareColor4);


    ShapeLog log1 = new ShapeLog(redSquare,1,redSquare2,10);
    ShapeLog log2 = new ShapeLog(redSquare2,10,redSquare3,15);
    ShapeLog log3 = new ShapeLog(redSquare3,15,redSquare4,20);

    animationModel.newMotion("red square", log1);
    assertEquals(1,animationModel.getShapeLog("red square").size());

    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 107 110 255 0 0\n",animationModel.outputDescriptions());

    animationModel.newMotion("red square", log3);
    animationModel.newMotion("red square", log2);


    assertEquals("shape red square Square\n"
        + "motion 1 50.000000 50.000000 100 100 255 0 0   10 50.000000 50.000000 107 110 255 0 0\n"
        + "motion 10 50.000000 50.000000 107 110 255 0 0   15 55.000000 50.000000 107 120 255 0 0\n"
        + "motion 15 55.000000 50.000000 107 120 255 0 0   20 50.000000 50.000000 107 110 255 0 0\n",animationModel.outputDescriptions());


  }





}
