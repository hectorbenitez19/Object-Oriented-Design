/**
 * This interface represents a Shape to be used in an animation. All shapes will have a Size, a
 * Name, A Color, and a Position on the Animation grid.
 */
public interface Shape {


  Size getSize();

  String getName();

  ShapeColor getColor();

  Position2D getPosition();

  void setPosition(Position2D newPosition);

  void setSize(Size newSize);

  void setColor(ShapeColor newColor);




}
