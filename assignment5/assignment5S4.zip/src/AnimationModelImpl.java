import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;



//(maybe)deletemotion deleteshape all change methods sortticksmethod addmotions

/**
 * Represents an object of an animation model. It contains various shapes that can move, change
 * dimensions, and change color while the animation is in action, and all motions of a shape must
 * not overlap (from time 1 to 10, a shape can't be moving in two different directions). A shape
 * must also not be able to teleport, or change it's state in an instantaneous moment.
 */
public class AnimationModelImpl implements AnimationModel {


  private final Map<String, Shape> shapes;
  private final Map<String, ArrayList<ShapeLog>> animationLog;

  /**
   * Constructs an object of the blank animation model with no shapes in it.
   */
  public AnimationModelImpl() {

    this.shapes = new HashMap<String, Shape>();
    this.animationLog = new HashMap<String, ArrayList<ShapeLog>>();
  }


  public void newMotion(String shapeName, ShapeLog shapelog) {
    //very first log for the shape
    if (animationLog.get(shapeName).isEmpty()) {
      if (!(shapelog.getStartShape().equals(shapes.get(shapeName)))) {
        throw new IllegalArgumentException(
            "starting shape state must agree with its previous shape state");
      }

    }

    for (ShapeLog l : animationLog.get(shapeName)) {
      if (shapelog.getStartTick() == l.getEndTick()) {
        if (!(shapelog.getStartShape().equals(l.getEndShape()))) {
          throw new IllegalArgumentException(
              "starting shape state must agree with its previous shape state");
        }
      }
      //if there is overlap between motions
      if (shapelog.getStartTick() >= l.getStartTick() && shapelog.getStartTick() < l.getEndTick() ||
          shapelog.getEndTick() > l.getStartTick() && shapelog.getEndTick() < l.getEndTick()) {
        throw new IllegalArgumentException("You cannot overlap motions.");
      }
    }

    // animationLog.get(shapeName).add(shapelog);
    ArrayList<ShapeLog> log = animationLog.get(shapeName);
    log = addInOrder(animationLog.get(shapeName), shapelog);

  //  addMotion(shapeName, shapelog);

  }


  public ArrayList<ShapeLog> addInOrder(ArrayList<ShapeLog> arraylogs, ShapeLog shapeLog) {
    if(arraylogs.isEmpty()) {
      arraylogs.add(shapeLog);
      return arraylogs;
    }

    for (int i = 0; i < arraylogs.size(); i++) {
      if(i == arraylogs.size() - 1) {
        if (arraylogs.get(i).getStartTick() >= shapeLog.getEndTick()) {
          arraylogs.add(i, shapeLog);
          break;
        }
        else {arraylogs.add(i+1, shapeLog);
        break;
        }

      }
      if (arraylogs.get(i).getStartTick() >= shapeLog.getEndTick()) {
        arraylogs.add(i, shapeLog);
        break;
      }
      else if (arraylogs.get(i).getEndTick() <= shapeLog.getStartTick()
          && shapeLog.getEndTick() <= arraylogs.get(i + 1).getStartTick()) {
        arraylogs.add(i + 1, shapeLog);
        break;
      }

    }
    return arraylogs;
  }



  @Override
  public void changePosition(String shapeName, Position2D to, int startTick, int endTick) {

    //if there is overlap between motions
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick >= l.getStartTick() && startTick < l.getEndTick() ||
          endTick >= l.getStartTick() && endTick < l.getEndTick()) {
        throw new IllegalArgumentException("You cannot overlap motions.");
      }

    }

    //if the user is trying to overwrite an existing motion
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick == l.getStartTick() && endTick == l.getEndTick()) {
        throw new IllegalArgumentException("You cannot change position during an existing motion");
      }
    }

    //if it is a valid motion then make a new log recording it and add it to the
    // shapeLogs for that shape.
    Shape oldShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    shapes.get(shapeName).setPosition(to);

    Shape newShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    ShapeLog newLog = new ShapeLog(oldShapeState, startTick, newShapeState, endTick);
    addMotion(shapeName, newLog);


  }

  @Override
  public void changeSize(String shapeName, Size size, int startTick, int endTick) {

//if there is overlap between motions
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick >= l.getStartTick() && startTick < l.getEndTick() ||
          endTick >= l.getStartTick() && endTick < l.getEndTick()) {
        throw new IllegalArgumentException("You cannot overlap motions.");
      }

    }

    //if the user is trying to overwrite an existing motion
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick == l.getStartTick() && endTick == l.getEndTick()) {
        throw new IllegalArgumentException("You cannot change position during an existing motion");
      }
    }

    //if it is a valid motion then make a new log recording it and add it to the
    // shapeLogs for that shape.
    Shape oldShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    shapes.get(shapeName).setSize(size);

    Shape newShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    ShapeLog newLog = new ShapeLog(oldShapeState, startTick, newShapeState, endTick);
    //newLog.setEndShape(to, shapes.get(shapeName).getSize(), newShapeState.getColor());
    addMotion(shapeName, newLog);


  }

  @Override
  public void changeColor(String shapeName, ShapeColor color, int startTick, int endTick) {

    //if there is overlap between motions
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick >= l.getStartTick() && startTick < l.getEndTick() ||
          endTick >= l.getStartTick() && endTick < l.getEndTick()) {
        throw new IllegalArgumentException("You cannot overlap motions.");
      }

    }

    //if the user is trying to overwrite an existing motion
    for (ShapeLog l : animationLog.get(shapeName)) {
      if (startTick == l.getStartTick() && endTick == l.getEndTick()) {
        throw new IllegalArgumentException("You cannot change position during an existing motion");
      }
    }

    //if it is a valid motion then make a new log recording it and add it to the
    // shapeLogs for that shape.
    Shape oldShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    shapes.get(shapeName).setColor(color);

    Shape newShapeState = new Square(shapes.get(shapeName).getName(),
        shapes.get(shapeName).getPosition(), shapes.get(shapeName).getSize(),
        shapes.get(shapeName).getColor());

    ShapeLog newLog = new ShapeLog(oldShapeState, startTick, newShapeState, endTick);
    //newLog.setEndShape(to, shapes.get(shapeName).getSize(), newShapeState.getColor());
    addMotion(shapeName, newLog);


  }

  @Override
  public void addShape(Shape shape) {
    if (this.shapes.containsKey(shape.getName())) {
      throw new IllegalArgumentException("This shape name already exists");
    }
    shapes.put(shape.getName(), shape);
    animationLog.put(shape.getName(), new ArrayList<ShapeLog>());
  }


  @Override
  public void addMotion(String shapeName, ShapeLog log) {
    if (!this.shapes.containsKey(shapeName)) {
      throw new IllegalArgumentException("That shape name does not exist");
    }
    animationLog.get(shapeName).add(log);

  }


  @Override
  public void deleteMotion(String shapeName, ShapeLog log) {
    ArrayList<Integer> startTicks = sortStartTicks(shapeName);
    int lastIndex = startTicks.size() - 1;
    if (startTicks.get(0) == log.getStartTick() || startTicks.get(lastIndex) == log
        .getStartTick()) {
      animationLog.get(shapeName).remove(log);
    } else {
      throw new IllegalStateException("You can only delete the first or last motion of a "
          + "specific shape.");
    }

  }


  @Override
  public void deleteShape(String shapeName) {
    if (!shapes.containsKey(shapeName)) {
      throw new IllegalArgumentException("That shape name does not exist");
    }
    shapes.remove(shapeName);
  }


  /**
   * Sorts the start ticks of a given shape's motions.
   *
   * @param shapeName the name of the shape whose start ticks will be sorted
   * @return a list of the start tick in order from smallest to largest
   * @throws IllegalArgumentException if the shape name doesn't exist in the animation
   */
  private ArrayList<Integer> sortStartTicks(String shapeName) {
    if (!shapes.containsKey(shapeName)) {
      throw new IllegalArgumentException("That shape name does not exist");
    }
    ArrayList<Integer> startTicks = new ArrayList<>();
    for (int i = 0; i < animationLog.get(shapeName).size(); i++) {
      startTicks.add(animationLog.get(shapeName).get(i).getStartTick());
    }
    Collections.sort(startTicks);
    return startTicks;
  }



  @Override
  public String outputDescriptions() {
    ArrayList<String> descriptions = new ArrayList<>();

    for (String shapename : animationLog.keySet()) {
      ArrayList<String> shapeInfo = new ArrayList<>();
      String shapeDeclaration = shapes.get(shapename).toString() + "\n";
      shapeInfo.add(shapeDeclaration);

      for (ShapeLog l : animationLog.get(shapename)) {
        shapeInfo.add(l.toString());
      }
      descriptions.add(String.join("", shapeInfo));
    }

    return String.join("\n", descriptions);
  }

/*
  public ArrayList<ShapeLog> getShapeLog(String shapeName) {
    return animationLog.get(shapeName);
  }

 */


}
