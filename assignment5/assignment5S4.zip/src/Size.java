import java.util.Objects;

/**
 * Represents a shape's size in terms of with and height.
 */
public class Size {
  private int width;
  private int height;

  /**
   * Constructs a size made up of width and height.
   * @param width the width of the shape
   * @param height the height of the shape
   */
  Size(int width, int height) {
    this.width = width;
    this.height = height;
  }

  public int getWidth() {
    return this.width;
  }

  public int getHeight() {
    return this.height;
  }

  public void setWidth(int width) {
    this.width = width;
  }

  public void setHeight(int height) {
    this.height = height;
  }

  @Override
  public String toString() {
    return String.format("%d %d", width,height);
  }

  @Override
  public boolean equals(Object a) {
    if (this == a) {
      return true;
    }
    if (!(a instanceof Size)) {
      return false;
    }

    Size that = (Size) a;

    return ((this.height == that.height) && (this.width == that.width));
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.height, this.width);
  }
}
