/**
 * Represents a log of motion for a shape in an animation. A log includes the starting and ending
 * ticks for that motion, and the state of the shape to begin with, and the state of the shape at
 * the end.
 */
public class ShapeLog {

  private final Shape startShape;
  private final Shape endShape;
  private final int startTick;
  private final int endTick;

  /**
   * Constructs a log of motion for shape with beginning and ending ticks.
   * @param startShape the starting state of the shape
   * @param startTick the start tick of the motion
   * @param endShape the ending state of the shape
   * @param endTick the ending tick of the motion
   */
  public ShapeLog(Shape startShape, int startTick, Shape endShape, int endTick) {
    this.startShape = startShape;
    this.endShape = endShape;
    this.startTick = startTick;
    this.endTick = endTick;
  }

  public int getStartTick() {
    return this.startTick;
  }

  public int getEndTick() {
    return this.endTick;
  }

  public void setStartShape(Position2D position, Size size, ShapeColor color) {
    this.startShape.setPosition(position);
    this.startShape.setColor(color);
    this.startShape.setSize(size);
  }

  public void setEndShape(Position2D position, Size size, ShapeColor color) {
    this.endShape.setPosition(position);
    this.endShape.setColor(color);
    this.endShape.setSize(size);
  }

  public Shape getStartShape() {
    return this.startShape;
  }

  public Shape getEndShape() {
    return this.endShape;
  }

  @Override
  public String toString() {
    return "motion " + startTick + " " + startShape.getPosition().toString() + " " + startShape.getSize().toString() + " " + startShape.getColor().toString() + "   "  +
        endTick + " " + endShape.getPosition().toString() + " " + endShape.getSize().toString() + " " + endShape.getColor().toString() + "\n";
  }

}
