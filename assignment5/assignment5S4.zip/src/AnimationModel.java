
/**
 * This interface represents a model for an animation. It contains the various operations that an
 * animation can perform, such as moving, changing dimensions, and changing color while the
 * animation is in action, and all motions of a shape must not overlap (from time 1 to 10, a shape
 * can't be moving in two different directions). A shape must also not be able to teleport, or
 * change it's state in an instantaneous moment. One object of the model represents one animation.
 */
public interface AnimationModel {


  /**
   * Changes the position of a shape in the animation (specified by the shape's name). A change in
   * position is allowed as long as the start and end tick of the action does not overlap with any
   * other existing motion in that shape's log of motion.
   *
   * @param shapeName the name of the shape to be move
   * @param to        the position that the shape is being moved to
   * @param startTick the start tick at which the move begins
   * @param endTick   the end tick at which the move will end
   */
  void changePosition(String shapeName, Position2D to, int startTick, int endTick);

  /**
   * Changes the dimensions of a shape in the animation (specified by the shape's name). A change in
   * size is allowed as long as the start and end tick of the action does not overlap with any other
   * existing motion in that shape's log of motion.
   *
   * @param shapeName the name of the shape that will change size
   * @param size the size of the shape
   * @param startTick the start tick at which the change will begin
   * @param endTick   the end tick at which the change will end
   */
  void changeSize(String shapeName, Size size, int startTick, int endTick);

  /**
   * Changes the color of a shape in the animation (specified by the shape's name). A change in
   * color is allowed as long as the start and end tick of the action does not overlap with any
   * other existing motion in that shape's log of motion.
   *
   * @param shapeName the name of the shape that will change color
   * @param color the color of the shape
   * @param startTick the start tick at which the change will begin
   * @param endTick   the end tick at which the change will end
   */
  void changeColor(String shapeName, ShapeColor color, int startTick, int endTick);

  /**
   * Adds a new shape to the animation. The shape must have a unique name that does not match any of
   * the shapes already existing in the animation.
   *
   * @param shape the shape to be added to the animation
   * @throws IllegalArgumentException if the shapeName is not unique
   */
  void addShape(Shape shape);

  /**
   * Deletes an existing shape from the animation.
   *
   * @param shapeName the shape to be added to the animation
   * @throws IllegalArgumentException if the shape specified does not already exist in the
   *                                  animation
   */
  void deleteShape(String shapeName);

  /**
   * Creates a new motion for the specified shape in the animation. A motion can only be added if
   * there is no
   * overlap to the already existing motions for that shape.
   *
   * @param shapeName the shape whose motion will be added
   * @param log       the motion that will be added to that shape
   * @throws IllegalArgumentException if the shape specified does not exist or if the log creates
   *                                  overlap
   */
  void addMotion(String shapeName, ShapeLog log);

  /**
   * Deletes a motion from the specified shape in the animation. A motion can only be deleted if
   * it is the first or last motion in that shape's log of motions in order to ensure no missin
   * information in the time line.
   * @param shapeName the shape that will have a deleted motion
   * @param log the motion that will be deleted from that shape's log
   * @throws IllegalArgumentException if the shape specified does not exist or if the log is not
   * either the first or last for that shape
   */
  void deleteMotion(String shapeName, ShapeLog log);

  /**
   * Outputs the motion logs for all shapes in the animation in String format.
   * @return the motion descriptions for all shapes in the animation
   */
  String outputDescriptions();


  //void newMotion(String shapeName,ShapeLog shapelog);

}
