import java.util.Objects;

/**
 * This class represents a 2D position that a shape can be positioned at.
 */
public class Position2D {

  private double x;
  private double y;

  /**
   * Constructs a 2D position based on x and y values.
   */
  public Position2D(double x, double y) {
    this.x = x;
    this.y = y;
  }

  public double getX() {
    return x;
  }

  public double getY() {
    return y;
  }

  public void setX(int x) {
    this.x = x;
  }

  public void setY(int y) {
    this.y = y;
  }


    /*
    /**
     * Copy constructor

    public Position2D(cs3500.turtle.model.Position2D v) {
      this(v.x, v.y);
    }

     */


  @Override
  public String toString() {
    return String.format("%f %f", this.x, this.y);
  }


  @Override
  public boolean equals(Object a) {
    if (this == a) {
      return true;
    }
    if (!(a instanceof Position2D)) {
      return false;
    }

    Position2D that = (Position2D) a;

    return ((Math.abs(this.x - that.x) < 0.01) && (Math.abs(this.y - that.y) < 0.01));
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.x, this.y);
  }




}
