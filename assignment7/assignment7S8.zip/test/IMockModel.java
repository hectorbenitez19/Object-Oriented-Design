import cs3500.animator.model.AnimationModel;

public interface IMockModel extends AnimationModel {

  String getCommandPressed();

}
