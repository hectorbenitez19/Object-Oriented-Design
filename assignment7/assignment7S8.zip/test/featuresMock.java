import cs3500.animator.controller.Features;

public interface featuresMock extends Features {

   String getCommandPressed();

}
