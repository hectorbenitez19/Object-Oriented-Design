import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelImpl;
import cs3500.marblesolitaire.model.hw02.Position;

public class MarbleSolitaireModelImpltest {

  private MarbleSolitaireModelImpl board1 = new MarbleSolitaireModelImpl();
  private MarbleSolitaireModelImpl board2 = new MarbleSolitaireModelImpl(5);
  private MarbleSolitaireModelImpl board3 = new MarbleSolitaireModelImpl();

  @Test
public void testGameState() {
    assertEquals(
        "    O O O\n"
        + "    O O O\n"
        + "O O O O O O O\n"
        + "O O O _ O O O\n"
        + "O O O O O O O\n"
        + "    O O O\n"
        + "    O O O", board1.getGameState());
  }



  @Test
  public void testThirdConstructor() {
    assertEquals(
        "        O O O O O\n"
        + "        O O O O O\n"
        + "        O O O O O\n"
        + "        O O O O O\n"
        + "O O O O O O O O O O O O O\n"
        + "O O O O O O O O O O O O O\n"
        + "O O O O O O _ O O O O O O\n"
        + "O O O O O O O O O O O O O\n"
        + "O O O O O O O O O O O O O\n"
        + "        O O O O O\n"
        + "        O O O O O\n"
        + "        O O O O O\n"
        + "        O O O O O", board2.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFourthConstructor() {
     MarbleSolitaireModelImpl board4 = new MarbleSolitaireModelImpl(3, 0, 0);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }



  @Test
  public void testValidMove() {
    board1.move(3, 1,3, 3);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O _ _ O O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMove() {
    board1.move(4, 5,5, 5);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMoveCorner() {
    board1.move(4, 5,-5, 5);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMoveEdge() {
    board1.move(4, 6,4, 7);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMoveInBoard() {
    board1.move(3, 0,3, 3);
    assertEquals(
        "    O O O\n"
            + "    O O O\n"
            + "O O O O O O O\n"
            + "O O O _ O O O\n"
            + "O O O O O O O\n"
            + "    O O O\n"
            + "    O O O", board1.getGameState());
  }


  @Test
  public void testGetScore() {
    assertEquals(32, board1.getScore());
  }



  @Test
  public void testIsGameOverFalse() {
    assertEquals(false, board1.isGameOver());

  }

  @Test
  public void testIsGameOverTrue() {
    board1.createGameOverBoard();
    assertEquals(true, board1.isGameOver());

  }



}
